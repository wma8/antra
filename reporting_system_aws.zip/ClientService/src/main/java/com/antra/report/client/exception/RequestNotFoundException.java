package com.antra.report.client.exception;

public class RequestNotFoundException extends RuntimeException{
}
