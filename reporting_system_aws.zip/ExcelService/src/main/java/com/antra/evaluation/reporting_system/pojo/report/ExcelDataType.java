package com.antra.evaluation.reporting_system.pojo.report;

public enum ExcelDataType {
    STRING, NUMBER, DATE
}
